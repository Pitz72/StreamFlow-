# Handoff: Restyle "Deco Dial" — Runtime StreamFlow

## Overview
Restyle estetico completo del client desktop **Runtime StreamFlow** (Electron + React 19 + TypeScript + Tailwind + Zustand). L'obiettivo è sostituire l'attuale tema "stone/dark generico" con il sistema estetico **Deco Dial**: retro-analogico, petrolio & ottone, VU meter ad ago d'epoca, pulsante ON AIR protagonista, con variante tema chiaro.

**Nessuna logica va modificata.** Store, IPC, hook audio, protocollo di streaming, validazioni e flussi restano identici. Cambiano esclusivamente markup di presentazione e classi/stili.

## About the Design Files
I file di questo bundle sono **riferimenti di design realizzati in HTML** (prototipi che mostrano look e comportamento voluti), NON codice di produzione da copiare direttamente. Il compito è **ricreare questi design nel codebase esistente** (React + Tailwind, dentro `src/renderer/`), riusando i pattern e i componenti già presenti. I componenti React esistenti (`App.tsx`, `OnAirButton.tsx`, `VuMeter.tsx`, ecc.) vanno rivestiti mantenendo props, stato e handler invariati.

## Fidelity
**High-fidelity (hifi).** Colori, tipografia, spaziature e stati sono definitivi. Ricreare l'UI in modo fedele. Le lancette dei VU meter nei mock oscillano con animazione CSS solo a scopo dimostrativo: nel codice reale la lancetta continua a essere pilotata dal livello audio reale (vedi `useAudioVisualizer` + `VuMeter`).

## Design Tokens

### Palette — Dark (default)
| Token | Hex | Uso |
|---|---|---|
| `bg` / deep | `#08201F` | sfondo finestra, fondo input, title-bar log |
| `surface` | `#0C2A27` | corpo modali |
| `petrol` / panel | `#12403C` | gradiente pannello principale (radial verso `#0A2A28`) |
| `panel-2` | `#0A2A28` | fine gradiente / superfici incassate |
| `brass` / accent | `#C8A44E` | filetti, label, bordi, pulsanti secondari, thumb slider |
| `on-air` / red | `#E0483A` | pulsante ON AIR live, dot ON AIR, toast errore |
| `red-deep` | `#B8302A` → `#8F2418` | gradiente pulsante ON AIR |
| `warn` / amber | `#E0B23A` | connecting / reconnecting |
| `error` / orange | `#E0742A` | stato error (dot + label) |
| `success` / teal | `#3D8A7F` | badge STREAM, pulsante "Applica", conferme |
| `metadata` / violet | `#7C58A8` (badge bg `rgba(124,88,168,.3)`, testo `#C4A9E0`) | badge METADATA |
| `ink` / cream | `#E6DDC4` | testo primario |
| `ink-strong` | `#F2EAD2` / `#E9E0C6` | display, valori enfatizzati |
| hairline oro | `rgba(200,164,78,.35)` | separatori, bordi hairline |

### Palette — Light
| Token | Hex | Uso |
|---|---|---|
| `bg` / parchment | `#F2ECD8` (gradiente verso `#E4D9BC`) | sfondo pannello |
| `surface` | `#E4D9BC` / title-bar `#CABF9C` | superfici |
| `ink` / petrol | `#173A36` | testo primario |
| `brass-dark` | `#A8802E` (label `#8A6A1E`) | accento su chiaro (contrasto AA) |
| on-air / red | `#C0392B` → `#8F2418` | pulsante ON AIR (invariato nel tono) |

### Colori di stato (dot + label header)
- READY `#5A6A4A` (dot spento) · CONNECTING `#E0B23A` (pulse) · ON AIR `#E0483A` (pulse) · ERROR `#E0742A` · RECONNECTING `#E0B23A` (pulse) + testo dettaglio countdown in amber.

### Tipografia
Caricare via Google Fonts (o self-host): `Oswald` (300–700), `Space Mono` (400/700), `Poiret One`.
- **Poiret One** — display: timer (76px), titoli modali (20–22px), wordmark "RUNTIME STREAMFLOW" (22px). `letter-spacing: 4–6px`.
- **Oswald** — UI: label (uppercase, 600, `letter-spacing:2px`, 10–11px), testo pulsanti (600, 12px), body/note (400, 11–14px).
- **Space Mono** — dati: host/porta/mount, valori %, timestamp e messaggi log, badge, versione. 10–13px, `tabular-nums` per i numeri variabili.

### Spacing (base 4px)
`8px` gap chip/dot · `12–16px` padding interno card · `13px 17px` padding slider volume · `20–22px` padding modale · `30px` padding orizzontale schermata · `44px` gap VU ↔ ON AIR · `26px` gap verticale blocchi main.

### Radius & ombre
- Radius: `2–3px` input/pulsanti/pill (linguaggio déco spigoloso) · `8px` card/modale/bezel VU · `50%` dot e pulsante ON AIR · `10–14px` window shell.
- Bordi: hairline oro `1px solid rgba(200,164,78,.35)`; bordo modale `rgba(200,164,78,.45)`.
- Ombre: modale `0 30px 70px rgba(0,0,0,.6)` · window `0 24px 60px rgba(0,0,0,.5)` · glow ON AIR live `0 0 40px rgba(224,72,58,.5)` + `inset 0 3px 10px rgba(255,255,255,.3)`.

## Screens / Views
Tutte le viste mappano 1:1 sui componenti esistenti in `src/renderer/`.

### 1. Schermata principale — `App.tsx`
- **Layout**: `flex flex-col h-screen`. Header (`justify-between`, padding `18px 30px`, hairline oro sotto). Main centrato (`flex-1 flex-col items-center justify-center`, gap 26px): blocco SESSION+timer, riga `[VU L] [ON AIR] [VU R]` (gap 44px), slider Input Volume (width 390px). Log bar in fondo (`shrink-0`).
- **Header**: dot stato (12px, colore per stato) · wordmark Poiret One (RUNTIME in cream, STREAMFLOW in brass) · pill stato (`Space Mono` 11px, bordo del colore di stato, radius 3px) · a destra pulsanti "Now Playing" / "Configurazione" (Oswald 600 uppercase, `background:transparent`, bordo `rgba(200,164,78,.5)`, radius 2px, testo brass), toggle tema (34×20 pill), versione mono.
- **Timer** (`Timer.tsx`): overline "◆ SESSION ◆" (Oswald 600, 11px, tracking 6px, brass). Cifre Poiret One 76px, `letter-spacing:6px`, colore `#F2EAD2`; dim (opacity ~.55) quando non live.
- **ON AIR** (`OnAirButton.tsx`): cerchio 140px in cornice brass (`padding:8px; border:2px solid rgba(200,164,78,.6)` + alone `box-shadow:0 0 0 6px rgba(200,164,78,.12)`). Bordo bottone 7px brass. Live: gradiente rosso `radial(#E0483A,#B8302A,#8F2418)` + glow rosso. Idle/Ready/Error: gradiente petrol scuro `radial(#183F3A,#102E2B)`, bordo/testo dim. Connecting: bordo/testo amber, testo "• • •" + "WAIT". Reconnecting: bordo `#A07A1E`, testo "ANNULLA / riconnessione" in amber. Testo: "GO" Poiret One 20px + "ON AIR" Oswald 700 24px.
- **VU meter** (`VuMeter.tsx`): vedi sezione dedicata sotto. Idle → wrapper `opacity:.4`.
- **Input Volume** (`InputVolumeControl.tsx`): card `background:rgba(10,42,40,.6)`, bordo oro, radius 3px, padding `13px 17px`. Label "INPUT VOLUME" (Oswald 600 uppercase, tracking 2px, brass) + valore % (Space Mono 700). Track 6px, fill brass, thumb 18px cream con bordo brass 2px. Overgain (>100): valore in `#E0742A`.
- **Log bar** (`StreamLog.tsx`): collassata → `background:#0A1A19`, top-border oro, `▲/▼ LOG` (Oswald 700 brass) + `[n]` mono + ultimo evento (badge + messaggio) + "CLEAR". Espansa → lista su `#061615`, righe `Space Mono` 12px: `timestamp` (dim) + badge sorgente + messaggio colorato per livello.

### 2. Modale Configurazione — `Modal.tsx` + `SettingsPanel.tsx` + `AzuraCastWizard.tsx`
- **Modal shell**: backdrop `bg-black/70 backdrop-blur`; card `#0C2A27`, bordo `rgba(200,164,78,.45)`, radius 8px, ombra `0 30px 70px rgba(0,0,0,.6)`. Header: titolo Poiret One 20px tracking 3px + "✕" brass; hairline oro; header bg `linear-gradient(rgba(200,164,78,.08),transparent)`.
- **Campi**: label Oswald 600 uppercase 10px tracking 2px brass; input/select `background:#08201F`, bordo `rgba(200,164,78,.3)`, radius 3px, padding `9px 11px`, testo cream; valori tecnici (host/port/user/mount) in `Space Mono`. Select con chevron "▾" brass. Ordine: [Configura da AzuraCast + ⓘ] · Server Profiles (select + "+ Salva profilo") · Audio Input Device · Host · Port · Icecast User (DJ) · Password · Mount Point · Bitrate · nota italic.
- **Wizard AzuraCast**: card `#0C2A27` bordo oro. Step 1: URL + API Key (+ⓘ) + "Carica stazioni" (pulsante brass pieno, testo `#0C2A27`). Step 2: select Stazione + "Carica DJ / Streamer". Step 3: box harbor `host:port/mount` (Space Mono teal), Porta DJ + Mount DJ, conferma teal "✓ Porta DJ letta…", select Account DJ, "✓ Applica configurazione" (pulsante teal `#3D8A7F`). Warning harbor inferred → amber.

### 3. Modale Now Playing — `NowPlayingPanel.tsx`
- Riga: label "Artist" (Oswald 600 uppercase, w-44 right) · input Artist · "—" brass · input Title · pulsante "Invia" (brass pieno se live, altrimenti disabilitato dim). Feedback: "✓ Inviato alle HH:MM" teal, allineato a destra; errore in box rosso. Toggle "▶ Dettagli risposta server (HTTP nnn)" → `<pre>` Space Mono su `#08201F`.

### 4. Toast errore — in `App.tsx`
- Fisso in basso-centro. `background:linear-gradient(#3A1512,#2A0F0D)`, bordo `rgba(224,72,58,.55)`, radius 10px, padding `13px 17px`, ombra profonda. "⚠" rosso + messaggio (Space Mono 12px `#F0C9C4`) + "✕" rosso. Auto-dismiss 5s (invariato).

## VU meter ad ago (`VuMeter.tsx`)
Sostituire le barre a segmenti con un **quadrante analogico ad ago** (SVG). Vedi `AnalogVu.dc.html` per l'implementazione di riferimento.
- SVG `viewBox 0 0 240 150` dentro bezel arrotondato (radius 10px, padding 9px) con ombre inset. Faccia chiara (`#EFE6CC`/`#FBF5E6`).
- Arco scala (raggio 92, da −46° a +46° attorno al perno `120,138`), zona rossa arco spesso da +20° a +46°, 10 tacche (ultime 3 in rosso), testo "VU" e "+3".
- **Ago**: `<rect x=118.5 y=50 w=3 h=88>` con `transform-box:fill-box; transform-origin:50% 100%`. **Nel codice reale la rotazione va pilotata dal livello audio** — mappare il valore di `useAudioVisualizer` (0..1) su un angolo circa −42°→+46° e scriverlo via `ref` sull'attributo `transform` (stesso pattern "no re-render per frame" già usato per l'altezza barra). Mozzo (`circle r=9`) sul perno.
- Props di temizzazione (face, bezel, ink, needle, red, glow, labelColor) per supportare dark/light: in dark ink/needle scuri su faccia crema; retroilluminazione via `radialGradient` `glow` in basso.
- Label "L"/"R" sotto (Oswald 600, tracking 3px, brass).

## Interactions & Behavior
Invariate rispetto all'attuale. Da preservare: guard anti doppio-GO, auto-invio metadata a `connected`, throttle ZMQ dello slider, autoscroll log, auto-dismiss toast 5s, chiusura modali con Esc, `closeOnBackdrop:false` per Configurazione. Transizioni: `transition-colors` sui pulsanti; pulse su dot connecting/on-air/reconnecting; glow del bottone ON AIR live.

## State Management
Nessuna modifica allo store Zustand (`useStore.ts`) né agli hook (`useAudioDevices`, `useAudioVisualizer`) o all'IPC (`window.electronAPI`). Aggiungere solo, se si implementa il toggle, uno stato tema `'dark' | 'light'` (persistito) che commuta le classi/variabili CSS — puramente presentazionale.

## Implementazione consigliata (Tailwind)
Estendere `tailwind.config.cjs` con i token e le famiglie font, così le classi generiche `stone-*` vengono sostituite da token semantici:

```js
// tailwind.config.cjs — theme.extend
colors: {
  deco: {
    bg:'#08201F', surface:'#0C2A27', petrol:'#12403C', panel:'#0A2A28',
    brass:'#C8A44E', brassInk:'#8A6A1E', ink:'#E6DDC4', inkStrong:'#F2EAD2',
    onair:'#E0483A', warn:'#E0B23A', error:'#E0742A', success:'#3D8A7F',
    // light
    parchment:'#F2ECD8', surfaceL:'#E4D9BC', inkL:'#173A36', brassDark:'#A8802E',
  }
},
fontFamily: {
  display: ['"Poiret One"','sans-serif'],
  ui: ['Oswald','system-ui','sans-serif'],
  mono: ['"Space Mono"','monospace'],
},
```
Poi, per ogni componente, mappare le classi attuali → nuove (es. `bg-stone-950`→`bg-deco-bg`, `bg-stone-900`→`bg-deco-surface`, accenti `blue-*`→`deco-brass`/`deco-success`, testo `stone-200/300`→`deco-ink`, `font-mono`→`font-mono` (Space Mono), timer/titoli→`font-display`). Il petrol del pannello principale usa un `bg-[radial-gradient(...)]` o una utility custom.

## Assets
Nessun asset raster. VU meter e trim sono SVG/CSS inline. Font da Google Fonts. Nessun logo esterno (white-label: "Runtime StreamFlow" come wordmark tipografico).

## Files (in questo bundle)
- `StreamFlow Redesign.dc.html` — prototipo completo: 3 direzioni iniziali (1a/1b/1c), approfondimento modali (2a/2b/2c) e il set completo Deco Dial (stati connessione, wizard, log espanso, tema chiaro).
- `AnalogVu.dc.html` — componente VU meter ad ago (riferimento SVG + props di tema).
- `Deco Dial — Style Guide.dc.html` — style guide visiva (palette, tipografia, spacing, radius, stati).
- `support.js` — runtime dei prototipi (solo per aprire i file HTML localmente; NON è codice di produzione).

Aprire i `.dc.html` in un browser per ispezionare misure/colori con i devtools. La direzione approvata è **Deco Dial** (blocco `1c` e turni `2`/`3`).
